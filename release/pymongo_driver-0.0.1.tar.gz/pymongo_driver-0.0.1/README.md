# pymongo-driver
pymongo-driver is a python module that brings a structured schema and validation layer on top of the great pymongo driver. It has been written to be as simple and light as possible with the KISS and DRY principles in mind.
